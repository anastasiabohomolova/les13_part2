from django.contrib import admin
from shop.models import Shoping

# Register your models here.

class ShopingModelAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'way', 'type')
    list_display_links = ('way',)
    list_editable = ('name', 'type')
    list_filter = ('name', 'price', 'type')
    search_fields = ['name']




admin.site.register(Shoping, ShopingModelAdmin)