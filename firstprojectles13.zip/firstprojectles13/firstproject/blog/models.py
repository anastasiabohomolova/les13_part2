from django.db import models

# Create your models here.

def topic_fields():
    home = 'дім'
    fields = [
        (home, 'дім'),
        ('food', 'їжа'),
        ('beatiful', 'краса')
    ]
    return fields
class Post(models.Model):
    title = models.CharField(max_length=40)
    content = models.TextField()
    update = models.DateTimeField(auto_now=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    topic = models.CharField(max_length=10, choices=topic_fields(), default='')
    file_for_content = models.FileField()          #файл, є стрічкою/зображенням, додаткова файлова інформація до контенту
    quantity_content = models.IntegerField()       #цифрове поле, ціле число, вказуватиме кількість контенту


    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return f'/blog/detail/{self.id}'